import pandas as pd
import numpy as np
from collections import Counter, defaultdict
from itertools import combinations
from sklearn.cluster import KMeans
from utils import load_resultados, get_numeros_from_row, save_analise_json, save_estatisticas_csv


def get_all_numeros(df):
    numeros = []
    cols = [f'N{i}' for i in range(1, 16)]
    for _, row in df.iterrows():
        for col in cols:
            if col in row:
                numeros.append(int(row[col]))
    return numeros


def frequencia_numeros(df):
    numeros = get_all_numeros(df)
    contagem = Counter(numeros)
    freq_df = pd.DataFrame([
        {'Numero': num, 'Frequencia': freq}
        for num, freq in sorted(contagem.items())
    ])
    return freq_df


def numeros_quentes_frios(df, n_ultimos=50):
    df_recente = df.head(n_ultimos)
    numeros = get_all_numeros(df_recente)
    contagem = Counter(numeros)
    
    todos_numeros = range(1, 26)
    freq = {num: contagem.get(num, 0) for num in todos_numeros}
    
    ordenados = sorted(freq.items(), key=lambda x: x[1], reverse=True)
    
    quentes = [num for num, _ in ordenados[:10]]
    frios = [num for num, _ in ordenados[-10:]]
    
    return {
        'quentes': quentes,
        'frios': frios,
        'frequencias': dict(ordenados)
    }


def repeticao_entre_concursos(df):
    resultados = []
    cols = [f'N{i}' for i in range(1, 16)]
    
    for i in range(len(df) - 1):
        atual = set(int(df.iloc[i][col]) for col in cols if col in df.columns)
        anterior = set(int(df.iloc[i + 1][col]) for col in cols if col in df.columns)
        
        repeticoes = len(atual & anterior)
        resultados.append({
            'Concurso': df.iloc[i]['Concurso'],
            'Concurso_Anterior': df.iloc[i + 1]['Concurso'],
            'Repeticoes': repeticoes,
            'Numeros_Repetidos': sorted(list(atual & anterior))
        })
    
    return pd.DataFrame(resultados)


def analise_pares(df, top_n=20):
    cols = [f'N{i}' for i in range(1, 16)]
    pares = []
    
    for _, row in df.iterrows():
        numeros = [int(row[col]) for col in cols if col in row]
        for par in combinations(sorted(numeros), 2):
            pares.append(par)
    
    contagem = Counter(pares)
    top_pares = contagem.most_common(top_n)
    
    return pd.DataFrame([
        {'Par': f"{p[0]}-{p[1]}", 'Frequencia': freq}
        for (p, freq) in top_pares
    ])


def analise_triplas(df, top_n=20):
    cols = [f'N{i}' for i in range(1, 16)]
    triplas = []
    
    for _, row in df.iterrows():
        numeros = [int(row[col]) for col in cols if col in row]
        for tripla in combinations(sorted(numeros), 3):
            triplas.append(tripla)
    
    contagem = Counter(triplas)
    top_triplas = contagem.most_common(top_n)
    
    return pd.DataFrame([
        {'Tripla': f"{t[0]}-{t[1]}-{t[2]}", 'Frequencia': freq}
        for (t, freq) in top_triplas
    ])


def analise_combinatoria(df):
    cols = [f'N{i}' for i in range(1, 16)]
    
    soma_total = []
    media_numeros = []
    pares_impares = []
    baixos_altos = []
    
    for _, row in df.iterrows():
        numeros = [int(row[col]) for col in cols if col in row]
        
        soma_total.append(sum(numeros))
        media_numeros.append(np.mean(numeros))
        
        pares = len([n for n in numeros if n % 2 == 0])
        impares = 15 - pares
        pares_impares.append(f"{pares}P-{impares}I")
        
        baixos = len([n for n in numeros if n <= 12])
        altos = 15 - baixos
        baixos_altos.append(f"{baixos}B-{altos}A")
    
    return {
        'soma': {
            'media': np.mean(soma_total),
            'min': min(soma_total),
            'max': max(soma_total),
            'std': np.std(soma_total)
        },
        'distribuicao_pares_impares': Counter(pares_impares).most_common(10),
        'distribuicao_baixos_altos': Counter(baixos_altos).most_common(10)
    }


def markov_ordem1(df):
    cols = [f'N{i}' for i in range(1, 16)]
    transicoes = defaultdict(lambda: defaultdict(int))
    
    for i in range(len(df) - 1):
        atual = set(int(df.iloc[i][col]) for col in cols if col in df.columns)
        proximo = set(int(df.iloc[i + 1][col]) for col in cols if col in df.columns)
        
        for num_atual in atual:
            for num_proximo in proximo:
                transicoes[num_atual][num_proximo] += 1
    
    matriz_prob = {}
    for num_atual, proximos in transicoes.items():
        total = sum(proximos.values())
        matriz_prob[num_atual] = {
            num_proximo: count / total
            for num_proximo, count in proximos.items()
        }
    
    return matriz_prob


def sugestao_markov(df, n_sugestoes=5):
    matriz = markov_ordem1(df)
    cols = [f'N{i}' for i in range(1, 16)]
    
    ultimo_concurso = df.iloc[0]
    numeros_ultimo = [int(ultimo_concurso[col]) for col in cols if col in ultimo_concurso]
    
    probabilidades = defaultdict(float)
    for num in numeros_ultimo:
        if num in matriz:
            for proximo, prob in matriz[num].items():
                probabilidades[proximo] += prob
    
    ordenados = sorted(probabilidades.items(), key=lambda x: x[1], reverse=True)
    return ordenados[:n_sugestoes]


def clustering_numeros(df, n_clusters=3):
    freq_df = frequencia_numeros(df)
    
    X = freq_df[['Frequencia']].values
    
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    freq_df['Cluster'] = kmeans.fit_predict(X)
    
    clusters = {}
    for cluster in range(n_clusters):
        nums = freq_df[freq_df['Cluster'] == cluster]['Numero'].tolist()
        media_freq = freq_df[freq_df['Cluster'] == cluster]['Frequencia'].mean()
        clusters[cluster] = {
            'numeros': nums,
            'media_frequencia': media_freq
        }
    
    return clusters


def gerar_analise_completa(df=None):
    if df is None:
        df = load_resultados()
    
    if df.empty:
        return None
    
    analise = {
        'total_concursos': len(df),
        'ultimo_concurso': int(df.iloc[0]['Concurso']) if not df.empty else 0,
        'frequencia': frequencia_numeros(df).to_dict('records'),
        'quentes_frios': numeros_quentes_frios(df),
        'combinatoria': analise_combinatoria(df),
        'top_pares': analise_pares(df).to_dict('records'),
        'top_triplas': analise_triplas(df).to_dict('records'),
        'clusters': clustering_numeros(df),
        'sugestao_markov': sugestao_markov(df)
    }
    
    save_analise_json(analise)
    
    freq_df = frequencia_numeros(df)
    save_estatisticas_csv(freq_df)
    
    return analise


if __name__ == "__main__":
    analise = gerar_analise_completa()
    if analise:
        print(f"Análise completa gerada para {analise['total_concursos']} concursos")
        print(f"Números quentes: {analise['quentes_frios']['quentes']}")
        print(f"Números frios: {analise['quentes_frios']['frios']}")
