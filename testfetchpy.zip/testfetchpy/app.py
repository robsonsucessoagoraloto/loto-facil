import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

from scraper import atualizar_resultados, criar_base_inicial, fetch_ultimo_resultado
from analysis import (
    frequencia_numeros, numeros_quentes_frios, repeticao_entre_concursos,
    analise_pares, analise_triplas, analise_combinatoria,
    markov_ordem1, sugestao_markov, clustering_numeros, gerar_analise_completa
)
from prediction import (
    gerar_previsao_combinada, gerar_alertas, analisar_bolao,
    salvar_previsoes, salvar_ranking_boloes, carregar_previsoes
)
from utils import (
    load_resultados,
    load_boloes,
    create_sample_boloes,
    update_all,
    RESULTADOS_FILE,
    BOLOES_FILE,
    ANALISE_JSON,
    PREVISOES_JSON,
    RANKING_BOLOES_CSV
)
)
from sheets import (
    verificar_credenciais, ler_boloes_sheets, get_service_account_email,
    load_sheets_config, save_sheets_config, sync_predictions_to_sheets,
    sync_rankings_to_sheets, load_boloes_from_sheets, listar_planilhas
)

st.set_page_config(
    page_title="Análise Lotofácil",
    page_icon="🍀",
    layout="wide"
)

st.title("🍀 Análise Lotofácil - Sistema Avançado")
st.markdown("---")

tab_dashboard, tab_estatisticas, tab_probabilidades, tab_boloes, tab_graficos, tab_sheets, tab_config = st.tabs([
    "📊 Dashboard", "📈 Estatísticas", "🎯 Probabilidades", 
    "📋 Analisar Bolões", "📉 Gráficos", "📋 Google Sheets", "⚙️ Configurações"
])


def plot_frequencia(freq_df):
    fig, ax = plt.subplots(figsize=(12, 6))
    colors = plt.cm.get_cmap('RdYlGn')(np.linspace(0, 1, len(freq_df)))
    ax.bar(freq_df['Numero'], freq_df['Frequencia'], color=colors)
    ax.set_xlabel('Número')
    ax.set_ylabel('Frequência')
    ax.set_title('Frequência dos Números na Lotofácil')
    ax.set_xticks(range(1, 26))
    plt.tight_layout()
    return fig


def plot_probabilidades(ranking):
    fig, ax = plt.subplots(figsize=(14, 6))
    
    nums = [n for n, _ in ranking]
    scores = [s for _, s in ranking]
    
    colors = ['green' if i < 15 else 'gray' if i < 20 else 'red' for i in range(len(nums))]
    
    ax.bar(range(len(nums)), scores, color=colors)
    ax.set_xticks(range(len(nums)))
    ax.set_xticklabels(nums)
    ax.set_xlabel('Número (ordenado por probabilidade)')
    ax.set_ylabel('Score de Probabilidade')
    ax.set_title('Ranking de Probabilidades - Verde: Prováveis | Cinza: Neutros | Vermelho: Frios')
    plt.tight_layout()
    return fig


def plot_quentes_frios(quentes_frios):
    fig, ax = plt.subplots(figsize=(10, 6))
    
    nums = list(quentes_frios['frequencias'].keys())
    freqs = list(quentes_frios['frequencias'].values())
    
    colors = ['red' if int(n) in quentes_frios['quentes'] else 
              'blue' if int(n) in quentes_frios['frios'] else 'gray' 
              for n in nums]
    
    ax.bar([int(n) for n in nums], freqs, color=colors)
    ax.set_xlabel('Número')
    ax.set_ylabel('Frequência')
    ax.set_title('Números Quentes (vermelho) vs Frios (azul)')
    ax.set_xticks(range(1, 26))
    plt.tight_layout()
    return fig


def plot_repeticoes(rep_df):
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.hist(rep_df['Repeticoes'], bins=range(0, 16), edgecolor='black', alpha=0.7)
    ax.set_xlabel('Quantidade de Repetições')
    ax.set_ylabel('Frequência')
    ax.set_title('Distribuição de Repetições entre Concursos Consecutivos')
    plt.tight_layout()
    return fig


def plot_pares_impares(combinatoria):
    fig, ax = plt.subplots(figsize=(10, 6))
    
    dist = combinatoria['distribuicao_pares_impares']
    labels = [item[0] for item in dist]
    values = [item[1] for item in dist]
    
    ax.bar(labels, values, color='purple', alpha=0.7)
    ax.set_xlabel('Distribuição Pares-Ímpares')
    ax.set_ylabel('Frequência')
    ax.set_title('Distribuição de Pares vs Ímpares')
    plt.xticks(rotation=45)
    plt.tight_layout()
    return fig


with tab_dashboard:
    st.header("📊 Dashboard Principal")
    
    df = load_resultados()
    
    if df.empty:
        st.warning("Nenhum dado disponível. Por favor, crie a base de dados primeiro.")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 Criar Base Inicial (100 concursos)", key="criar_base"):
                with st.spinner("Buscando dados da Caixa..."):
                    df = criar_base_inicial(100)
                    if not df.empty:
                        st.success(f"Base criada com {len(df)} concursos!")
                        st.rerun()
                    else:
                        st.error("Erro ao criar base de dados")
    else:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total de Concursos", len(df))
        
        with col2:
            st.metric("Último Concurso", int(df.iloc[0]['Concurso']))
        
        with col3:
            st.metric("Data Último", df.iloc[0]['Data'])
        
        with col4:
            quentes = numeros_quentes_frios(df)['quentes']
            st.metric("Número Mais Quente", quentes[0] if quentes else "-")
        
        st.markdown("---")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Últimos 5 Concursos")
            cols_display = ['Concurso', 'Data'] + [f'N{i}' for i in range(1, 16)]
            st.dataframe(df[cols_display].head(5), use_container_width=True)
        
        with col2:
            st.subheader("Ações Rápidas")
            
            if st.button("🔄 Atualizar Tudo", key="update_all_dash"):
                with st.spinner("Executando atualização completa..."):
                    result = update_all()
                    if result:
                        st.success("Atualização completa realizada!")
                        st.rerun()
            
            if st.button("📥 Buscar Novos Concursos", key="atualizar_dash"):
                with st.spinner("Buscando..."):
                    df_novo, falhas = atualizar_resultados(50)
                    st.success(f"Base atualizada! Total: {len(df_novo)} concursos")
                    if falhas:
                        st.warning(f"Concursos com falha: {falhas}")
                    st.rerun()

with tab_estatisticas:
    st.header("📈 Estatísticas Detalhadas")
    
    df = load_resultados()
    
    if df.empty:
        st.warning("Carregue os dados primeiro na aba Dashboard.")
    else:
        n_concursos = st.slider("Analisar últimos N concursos:", 10, min(500, len(df)), min(100, len(df)), key="n_conc_estat")
        df_analise = df.head(n_concursos)
        
        subtab1, subtab2, subtab3, subtab4, subtab5 = st.tabs([
            "Frequência", "Quentes/Frios", "Repetições", "Pares/Triplas", "Combinatória"
        ])
        
        with subtab1:
            st.subheader("Frequência dos Números")
            freq_df = frequencia_numeros(df_analise)
            
            col1, col2 = st.columns([2, 1])
            with col1:
                fig = plot_frequencia(freq_df)
                st.pyplot(fig)
            with col2:
                st.dataframe(freq_df.sort_values('Frequencia', ascending=False), use_container_width=True)
        
        with subtab2:
            st.subheader("Números Quentes e Frios")
            quentes_frios = numeros_quentes_frios(df_analise, n_concursos)
            
            col1, col2 = st.columns(2)
            with col1:
                st.write("🔥 **Números Quentes (mais frequentes):**")
                st.write(quentes_frios['quentes'])
            with col2:
                st.write("❄️ **Números Frios (menos frequentes):**")
                st.write(quentes_frios['frios'])
            
            fig = plot_quentes_frios(quentes_frios)
            st.pyplot(fig)
        
        with subtab3:
            st.subheader("Repetições entre Concursos")
            rep_df = repeticao_entre_concursos(df_analise)
            
            col1, col2 = st.columns([1, 2])
            with col1:
                st.metric("Média de Repetições", f"{rep_df['Repeticoes'].mean():.2f}")
                st.metric("Máximo", int(rep_df['Repeticoes'].max()))
                st.metric("Mínimo", int(rep_df['Repeticoes'].min()))
            with col2:
                fig = plot_repeticoes(rep_df)
                st.pyplot(fig)
        
        with subtab4:
            st.subheader("Análise de Pares e Triplas")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Top 15 Pares:**")
                pares_df = analise_pares(df_analise, 15)
                st.dataframe(pares_df, use_container_width=True)
            
            with col2:
                st.write("**Top 15 Triplas:**")
                triplas_df = analise_triplas(df_analise, 15)
                st.dataframe(triplas_df, use_container_width=True)
        
        with subtab5:
            st.subheader("Análise Combinatória")
            comb = analise_combinatoria(df_analise)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Estatísticas de Soma:**")
                st.write(f"- Média: {comb['soma']['media']:.2f}")
                st.write(f"- Mínimo: {comb['soma']['min']}")
                st.write(f"- Máximo: {comb['soma']['max']}")
                st.write(f"- Desvio Padrão: {comb['soma']['std']:.2f}")
            
            with col2:
                st.write("**Distribuição Pares/Ímpares:**")
                for item in comb['distribuicao_pares_impares'][:5]:
                    st.write(f"- {item[0]}: {item[1]} vezes")

with tab_probabilidades:
    st.header("🎯 Sistema de Previsão")
    
    df = load_resultados()
    
    if df.empty:
        st.warning("Carregue os dados primeiro na aba Dashboard.")
    else:
        st.subheader("Configuração dos Pesos")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            peso_markov = st.slider("Peso Markov", 0.0, 1.0, 0.30, 0.05, key="peso_markov")
        with col2:
            peso_freq = st.slider("Peso Frequência", 0.0, 1.0, 0.25, 0.05, key="peso_freq")
        with col3:
            peso_tend = st.slider("Peso Tendência", 0.0, 1.0, 0.25, 0.05, key="peso_tend")
        with col4:
            peso_reg = st.slider("Peso Regressão", 0.0, 1.0, 0.20, 0.05, key="peso_reg")
        
        n_concursos_prev = st.slider("Concursos para análise:", 20, min(300, len(df)), min(100, len(df)), key="n_conc_prev")
        
        if st.button("🎯 Gerar Previsões", key="gerar_prev"):
            with st.spinner("Calculando probabilidades..."):
                pesos = {
                    'markov': peso_markov,
                    'frequencia': peso_freq,
                    'tendencia': peso_tend,
                    'regressao': peso_reg
                }
                
                previsao = gerar_previsao_combinada(df, pesos, n_concursos_prev)
                alertas = gerar_alertas(previsao)
                salvar_previsoes(previsao, alertas)
                
                st.session_state['previsao'] = previsao
                st.session_state['alertas'] = alertas
                st.success("Previsões geradas e salvas!")
        
        if 'previsao' in st.session_state:
            previsao = st.session_state['previsao']
            alertas = st.session_state['alertas']
            
            st.markdown("---")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.subheader("🟢 Top 15 Prováveis")
                for i, num in enumerate(alertas['provaveis_top15'], 1):
                    score = previsao['detalhes'][num]['score_final']
                    st.write(f"{i:2d}. Número **{num:2d}** (score: {score:.4f})")
            
            with col2:
                st.subheader("🟡 Neutros")
                for num in alertas['neutros']:
                    score = previsao['detalhes'][num]['score_final']
                    st.write(f"Número **{num:2d}** (score: {score:.4f})")
            
            with col3:
                st.subheader("🔴 Friíssimos")
                for num in alertas['friissimos']:
                    score = previsao['detalhes'][num]['score_final']
                    st.write(f"Número **{num:2d}** (score: {score:.4f})")
            
            st.markdown("---")
            st.subheader("📌 Sugestão de Jogo")
            st.success(f"Números sugeridos: **{alertas['sugestao_jogo']}**")
            
            st.subheader("Gráfico de Probabilidades")
            fig = plot_probabilidades(previsao['ranking'])
            st.pyplot(fig)
            
            st.markdown("---")
            st.subheader("Detalhes por Método")
            
            detalhes_df = pd.DataFrame([
                {
                    'Número': num,
                    'Markov': previsao['detalhes'][num]['markov'],
                    'Frequência': previsao['detalhes'][num]['frequencia'],
                    'Tendência': previsao['detalhes'][num]['tendencia'],
                    'Regressão': previsao['detalhes'][num]['regressao'],
                    'Score Final': previsao['detalhes'][num]['score_final']
                }
                for num in range(1, 26)
            ])
            detalhes_df = detalhes_df.sort_values('Score Final', ascending=False)
            st.dataframe(detalhes_df, use_container_width=True)
            
            if st.button("💾 Exportar Previsões (JSON)", key="export_prev"):
                st.success(f"Previsões salvas em: {PREVISOES_JSON}")

with tab_boloes:
    st.header("📋 Análise de Bolões")
    
    df = load_resultados()
    
    if df.empty:
        st.warning("Carregue os dados primeiro na aba Dashboard.")
    else:
        subtab_carregar, subtab_analisar = st.tabs(["Carregar Bolões", "Ranking"])
        
        with subtab_carregar:
            st.subheader("Carregar Bolões")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Upload de CSV:**")
                uploaded_file = st.file_uploader("Escolha um arquivo CSV", type="csv", key="upload_bolao")
                
                if uploaded_file:
                    df_boloes = pd.read_csv(uploaded_file)
                    df_boloes.to_csv(BOLOES_FILE, index=False)
                    st.success("Arquivo carregado!")
                    st.dataframe(df_boloes)
                
                if st.button("📄 Criar Bolões de Exemplo", key="criar_exemplo"):
                    df_exemplo = create_sample_boloes()
                    st.success(f"Arquivo de exemplo criado!")
                    st.dataframe(df_exemplo)
            
            with col2:
                st.write("**Google Sheets:**")
                if verificar_credenciais():
                    st.success("✅ Credenciais configuradas!")
                    planilha_nome = st.text_input("Nome da Planilha:", key="plan_nome")
                    aba_nome = st.text_input("Nome da Aba:", value="Bolões", key="aba_nome")
                    
                    if st.button("📊 Carregar do Sheets", key="carregar_sheets"):
                        try:
                            df_sheets = ler_boloes_sheets(planilha_nome, aba_nome)
                            df_sheets.to_csv(BOLOES_FILE, index=False)
                            st.success("Dados carregados!")
                            st.dataframe(df_sheets)
                        except Exception as e:
                            st.error(f"Erro: {e}")
                else:
                    st.warning("⚠️ Credenciais não configuradas")
                    st.markdown("Salve `credentials.json` na pasta do projeto")
        
        with subtab_analisar:
            st.subheader("Ranking de Bolões")
            
            boloes_df = load_boloes()
            
            if boloes_df.empty:
                st.info("Carregue seus bolões primeiro.")
            else:
                st.write(f"**{len(boloes_df)} jogos carregados**")
                
                if 'previsao' not in st.session_state:
                    st.warning("Gere as previsões primeiro na aba 'Probabilidades'")
                    if st.button("🎯 Gerar Previsões Agora", key="gerar_prev_bolao"):
                        with st.spinner("Calculando..."):
                            previsao = gerar_previsao_combinada(df)
                            alertas = gerar_alertas(previsao)
                            st.session_state['previsao'] = previsao
                            st.session_state['alertas'] = alertas
                            st.rerun()
                else:
                    previsao = st.session_state['previsao']
                    
                    if st.button("📊 Analisar Bolões", key="analisar_boloes"):
                        with st.spinner("Analisando..."):
                            ranking_df = analisar_bolao(boloes_df, previsao, df)
                            salvar_ranking_boloes(ranking_df)
                            st.session_state['ranking_boloes'] = ranking_df
                            st.success("Análise concluída!")
                    
                    if 'ranking_boloes' in st.session_state:
                        ranking_df = st.session_state['ranking_boloes']
                        
                        st.subheader("🏆 Ranking por Força")
                        
                        st.dataframe(
                            ranking_df[['posicao', 'bolao_id', 'jogo_id', 'numeros', 'forca', 'acertos_provaveis', 'numeros_frios']],
                            use_container_width=True
                        )
                        
                        st.markdown("---")
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Melhor Jogo", f"Bolão {ranking_df.iloc[0]['bolao_id']} - Jogo {ranking_df.iloc[0]['jogo_id']}")
                        with col2:
                            st.metric("Força Máxima", f"{ranking_df.iloc[0]['forca']:.2f}")
                        with col3:
                            st.metric("Força Média", f"{ranking_df['forca'].mean():.2f}")
                        
                        if st.button("💾 Exportar Ranking (CSV)", key="export_ranking"):
                            st.success(f"Ranking salvo em: {RANKING_BOLOES_CSV}")

with tab_graficos:
    st.header("📉 Gráficos")
    
    df = load_resultados()
    
    if df.empty:
        st.warning("Carregue os dados primeiro.")
    else:
        grafico = st.selectbox(
            "Escolha o gráfico:",
            ["Frequência dos Números", "Quentes vs Frios", 
             "Distribuição de Repetições", "Pares vs Ímpares", "Probabilidades"]
        )
        
        n_graf = st.slider("Últimos N concursos:", 10, min(500, len(df)), min(100, len(df)), key="n_graf")
        df_graf = df.head(n_graf)
        
        if grafico == "Frequência dos Números":
            freq_df = frequencia_numeros(df_graf)
            fig = plot_frequencia(freq_df)
            st.pyplot(fig)
        
        elif grafico == "Quentes vs Frios":
            quentes_frios = numeros_quentes_frios(df_graf, n_graf)
            fig = plot_quentes_frios(quentes_frios)
            st.pyplot(fig)
        
        elif grafico == "Distribuição de Repetições":
            rep_df = repeticao_entre_concursos(df_graf)
            fig = plot_repeticoes(rep_df)
            st.pyplot(fig)
        
        elif grafico == "Pares vs Ímpares":
            comb = analise_combinatoria(df_graf)
            fig = plot_pares_impares(comb)
            st.pyplot(fig)
        
        elif grafico == "Probabilidades":
            if 'previsao' in st.session_state:
                fig = plot_probabilidades(st.session_state['previsao']['ranking'])
                st.pyplot(fig)
            else:
                st.info("Gere as previsões primeiro na aba 'Probabilidades'")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("💾 Salvar Gráfico (PNG)", key="salvar_graf"):
                filename = f"data/{grafico.replace(' ', '_').lower()}.png"
                plt.savefig(filename, dpi=150, bbox_inches='tight')
                st.success(f"Gráfico salvo: {filename}")

with tab_sheets:
    st.header("📋 Integração Google Sheets")
    
    if verificar_credenciais():
        st.success("✅ Credenciais do Google configuradas!")
        
        email = get_service_account_email()
        if email:
            st.info(f"📧 Conta de serviço: **{email}**\n\nCompartilhe suas planilhas com este email para permitir acesso.")
        
        config = load_sheets_config()
        
        st.subheader("Configuração de Planilhas")
        st.write("Insira os IDs das planilhas do Google Sheets (encontre o ID na URL da planilha)")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            boloes_id = st.text_input(
                "ID Planilha de Bolões:",
                value=config.get('boloes_sheet_id', ''),
                key="boloes_sheet_id",
                help="Planilha com colunas: bolao_id, jogo_id, numeros"
            )
        
        with col2:
            previsoes_id = st.text_input(
                "ID Planilha de Previsões:",
                value=config.get('previsoes_sheet_id', ''),
                key="previsoes_sheet_id",
                help="Onde as previsões serão exportadas"
            )
        
        with col3:
            rankings_id = st.text_input(
                "ID Planilha de Rankings:",
                value=config.get('rankings_sheet_id', ''),
                key="rankings_sheet_id",
                help="Onde o ranking de bolões será exportado"
            )
        
        if st.button("💾 Salvar Configuração", key="salvar_config_sheets"):
            new_config = {
                'boloes_sheet_id': boloes_id,
                'previsoes_sheet_id': previsoes_id,
                'rankings_sheet_id': rankings_id
            }
            save_sheets_config(new_config)
            st.success("Configuração salva!")
            st.rerun()
        
        st.markdown("---")
        st.subheader("Ações")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.write("**Carregar Bolões:**")
            if st.button("📥 Carregar Bolões do Sheets", key="carregar_boloes_sheets"):
                if not config.get('boloes_sheet_id'):
                    st.error("Configure o ID da planilha de bolões primeiro")
                else:
                    try:
                        with st.spinner("Carregando..."):
                            df_boloes = load_boloes_from_sheets(config['boloes_sheet_id'])
                            from utils import save_boloes
                            save_boloes(df_boloes)
                            st.success(f"Carregados {len(df_boloes)} jogos!")
                            st.dataframe(df_boloes)
                    except Exception as e:
                        st.error(f"Erro: {e}")
        
        with col2:
            st.write("**Enviar Previsões:**")
            if st.button("📤 Enviar Previsões para Sheets", key="enviar_previsoes_sheets"):
                if not config.get('previsoes_sheet_id'):
                    st.error("Configure o ID da planilha de previsões primeiro")
                else:
                    try:
                        with st.spinner("Enviando..."):
                            url = sync_predictions_to_sheets(config['previsoes_sheet_id'])
                            st.success(f"Previsões enviadas!")
                            st.write(f"[Abrir planilha]({url})")
                    except Exception as e:
                        st.error(f"Erro: {e}")
        
        with col3:
            st.write("**Enviar Rankings:**")
            if st.button("📤 Enviar Rankings para Sheets", key="enviar_rankings_sheets"):
                if not config.get('rankings_sheet_id'):
                    st.error("Configure o ID da planilha de rankings primeiro")
                else:
                    try:
                        with st.spinner("Enviando..."):
                            url = sync_rankings_to_sheets(config['rankings_sheet_id'])
                            st.success(f"Rankings enviados!")
                            st.write(f"[Abrir planilha]({url})")
                    except Exception as e:
                        st.error(f"Erro: {e}")
        
        st.markdown("---")
        st.subheader("Planilhas Disponíveis")
        
        if st.button("🔄 Listar Planilhas", key="listar_planilhas"):
            try:
                with st.spinner("Buscando..."):
                    planilhas = listar_planilhas()
                    if planilhas:
                        df_plan = pd.DataFrame(planilhas)
                        st.dataframe(df_plan, use_container_width=True)
                    else:
                        st.info("Nenhuma planilha compartilhada com a conta de serviço.")
            except Exception as e:
                st.error(f"Erro: {e}")
    
    else:
        st.warning("⚠️ Credenciais do Google Sheets não configuradas")
        
        st.markdown("""
        ### Como configurar:
        
        1. **Crie um projeto** no [Google Cloud Console](https://console.cloud.google.com/)
        2. **Ative as APIs**:
           - Google Sheets API
           - Google Drive API
        3. **Crie uma conta de serviço**:
           - Menu → IAM e Admin → Contas de serviço
           - Criar conta de serviço
           - Baixar chave JSON
        4. **Configure o projeto**:
           - Renomeie o arquivo para `credentials.json`
           - Coloque na pasta raiz do projeto
        5. **Compartilhe suas planilhas**:
           - Abra cada planilha no Google Sheets
           - Clique em "Compartilhar"
           - Adicione o email da conta de serviço (está no arquivo JSON)
           - Dê permissão de "Editor"
        
        ### Formato da planilha de bolões:
        
        A planilha deve ter as colunas:
        - `bolao_id`: ID do bolão
        - `jogo_id`: ID do jogo dentro do bolão
        - `numeros`: números separados por vírgula (ex: 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
        """)

with tab_config:
    st.header("⚙️ Configurações e Atualização")
    
    st.subheader("Atualização de Dados")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Buscar Último Resultado:**")
        if st.button("📥 Verificar Último Concurso", key="ver_ultimo"):
            with st.spinner("Buscando..."):
                resultado = fetch_ultimo_resultado()
                if resultado:
                    st.success(f"Concurso {resultado['Concurso']}")
                    st.json(resultado)
                else:
                    st.error("Erro ao buscar")
    
    with col2:
        st.write("**Criar Nova Base:**")
        qtd = st.slider("Quantidade de concursos:", 50, 500, 100, key="qtd_nova_base")
        if st.button("🆕 Criar Nova Base", key="nova_base"):
            with st.spinner(f"Buscando {qtd} concursos..."):
                df = criar_base_inicial(qtd)
                if not df.empty:
                    st.success(f"Base criada com {len(df)} concursos!")
                    st.rerun()
    
    st.markdown("---")
    st.subheader("Atualização Completa (update_all)")
    st.write("Executa: atualizar dados → gerar análises → gerar previsões → analisar bolões")
    
    if st.button("🔄 Executar Atualização Completa", key="update_all_config"):
        with st.spinner("Executando..."):
            result = update_all()
            if result:
                st.session_state['previsao'] = result['previsao']
                st.session_state['alertas'] = result['alertas']
                st.success("Atualização completa realizada!")
                st.rerun()
    
    st.markdown("---")
    st.subheader("Arquivos Gerados")
    
    arquivos = [
        (RESULTADOS_FILE, "Resultados dos concursos"),
        (ANALISE_JSON, "Análises estatísticas"),
        (PREVISOES_JSON, "Previsões de probabilidade"),
        (RANKING_BOLOES_CSV, "Ranking dos bolões"),
    ]
    
    for arquivo, descricao in arquivos:
        existe = "✅" if os.path.exists(arquivo) else "❌"
        st.write(f"{existe} **{arquivo}** - {descricao}")

st.sidebar.markdown("---")
st.sidebar.subheader("ℹ️ Instruções")
st.sidebar.markdown("""
1. **Dashboard**: Visão geral e ações rápidas
2. **Estatísticas**: Análises detalhadas
3. **Probabilidades**: Sistema de previsão
4. **Analisar Bolões**: Ranking por força
5. **Gráficos**: Visualizações
6. **Google Sheets**: Integração com planilhas
7. **Configurações**: Atualização e exportação
""")

st.sidebar.markdown("---")
df = load_resultados()
if not df.empty:
    st.sidebar.success(f"📊 {len(df)} concursos carregados")
else:
    st.sidebar.warning("⚠️ Sem dados carregados")
