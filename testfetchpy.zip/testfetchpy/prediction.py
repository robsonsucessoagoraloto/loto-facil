import pandas as pd
import numpy as np
from collections import Counter, defaultdict
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import warnings
from utils import load_resultados, ensure_data_dir, DATA_DIR
import json
import os

warnings.filterwarnings('ignore')

PREVISOES_JSON = os.path.join(DATA_DIR, "previsoes.json")
RANKING_BOLOES_CSV = os.path.join(DATA_DIR, "ranking_boloes.csv")


def get_numeros_concurso(row):
    cols = [f'N{i}' for i in range(1, 16)]
    return [int(row[col]) for col in cols if col in row.index]


def probabilidade_markov(df, n_ultimos=None):
    if n_ultimos:
        df = df.head(n_ultimos)
    
    cols = [f'N{i}' for i in range(1, 16)]
    transicoes = defaultdict(lambda: defaultdict(int))
    
    for i in range(len(df) - 1):
        atual = set(int(df.iloc[i][col]) for col in cols if col in df.columns)
        proximo = set(int(df.iloc[i + 1][col]) for col in cols if col in df.columns)
        
        for num_atual in atual:
            for num_proximo in proximo:
                transicoes[num_atual][num_proximo] += 1
    
    matriz_prob = {}
    for num_atual, proximos in transicoes.items():
        total = sum(proximos.values())
        matriz_prob[num_atual] = {
            num_proximo: count / total
            for num_proximo, count in proximos.items()
        }
    
    ultimo_concurso = df.iloc[0]
    numeros_ultimo = [int(ultimo_concurso[col]) for col in cols if col in ultimo_concurso]
    
    probabilidades = defaultdict(float)
    for num in range(1, 26):
        for num_anterior in numeros_ultimo:
            if num_anterior in matriz_prob and num in matriz_prob[num_anterior]:
                probabilidades[num] += matriz_prob[num_anterior][num]
    
    max_prob = max(probabilidades.values()) if probabilidades else 1
    return {num: prob / max_prob for num, prob in probabilidades.items()}


def probabilidade_frequencia_ponderada(df, n_ultimos=100, decay=0.98):
    df_subset = df.head(n_ultimos)
    cols = [f'N{i}' for i in range(1, 16)]
    
    pontuacao = defaultdict(float)
    
    for idx, (_, row) in enumerate(df_subset.iterrows()):
        peso = decay ** idx
        numeros = [int(row[col]) for col in cols if col in row]
        for num in numeros:
            pontuacao[num] += peso
    
    max_pont = max(pontuacao.values()) if pontuacao else 1
    return {num: pont / max_pont for num, pont in pontuacao.items()}


def probabilidade_tendencia(df, janela_curta=10, janela_longa=50):
    cols = [f'N{i}' for i in range(1, 16)]
    
    def contar_freq(subset):
        numeros = []
        for _, row in subset.iterrows():
            for col in cols:
                if col in row:
                    numeros.append(int(row[col]))
        return Counter(numeros)
    
    freq_curta = contar_freq(df.head(janela_curta))
    freq_longa = contar_freq(df.head(janela_longa))
    
    tendencias = {}
    for num in range(1, 26):
        taxa_curta = freq_curta.get(num, 0) / janela_curta
        taxa_longa = freq_longa.get(num, 0) / janela_longa
        
        if taxa_longa > 0:
            tendencias[num] = (taxa_curta / taxa_longa) - 1
        else:
            tendencias[num] = 0
    
    min_tend = min(tendencias.values())
    max_tend = max(tendencias.values())
    range_tend = max_tend - min_tend if max_tend != min_tend else 1
    
    return {num: (tend - min_tend) / range_tend for num, tend in tendencias.items()}


def probabilidade_regressao_logistica(df, n_ultimos=200):
    df_subset = df.head(n_ultimos).copy()
    cols = [f'N{i}' for i in range(1, 16)]
    
    probabilidades = {}
    
    for num_alvo in range(1, 26):
        X_list = []
        y_list = []
        
        for i in range(len(df_subset) - 1):
            row_atual = df_subset.iloc[i]
            row_proximo = df_subset.iloc[i + 1]
            
            numeros_atual = [int(row_atual[col]) for col in cols if col in row_atual]
            numeros_proximo = [int(row_proximo[col]) for col in cols if col in row_proximo]
            
            features = [
                1 if num_alvo in numeros_atual else 0,
                numeros_atual.count(num_alvo) if num_alvo <= 25 else 0,
                sum(1 for n in numeros_atual if abs(n - num_alvo) <= 2),
                1 if num_alvo % 2 == 0 else 0,
                1 if num_alvo <= 12 else 0,
            ]
            
            X_list.append(features)
            y_list.append(1 if num_alvo in numeros_proximo else 0)
        
        X = np.array(X_list)
        y = np.array(y_list)
        
        if len(set(y)) > 1:
            try:
                scaler = StandardScaler()
                X_scaled = scaler.fit_transform(X)
                
                model = LogisticRegression(random_state=42, max_iter=1000)
                model.fit(X_scaled, y)
                
                ultimo_row = df_subset.iloc[0]
                numeros_ultimo = [int(ultimo_row[col]) for col in cols if col in ultimo_row]
                
                features_pred = [
                    1 if num_alvo in numeros_ultimo else 0,
                    0,
                    sum(1 for n in numeros_ultimo if abs(n - num_alvo) <= 2),
                    1 if num_alvo % 2 == 0 else 0,
                    1 if num_alvo <= 12 else 0,
                ]
                
                X_pred = scaler.transform([features_pred])
                prob = model.predict_proba(X_pred)[0][1]
                probabilidades[num_alvo] = prob
            except Exception:
                probabilidades[num_alvo] = 0.5
        else:
            probabilidades[num_alvo] = y.mean() if len(y) > 0 else 0.5
    
    max_prob = max(probabilidades.values()) if probabilidades else 1
    return {num: prob / max_prob for num, prob in probabilidades.items()}


def gerar_previsao_combinada(df, pesos=None, n_ultimos=100):
    if pesos is None:
        pesos = {
            'markov': 0.30,
            'frequencia': 0.25,
            'tendencia': 0.25,
            'regressao': 0.20
        }
    
    soma_pesos = sum(pesos.values())
    pesos = {k: v / soma_pesos for k, v in pesos.items()}
    
    prob_markov = probabilidade_markov(df, n_ultimos)
    prob_freq = probabilidade_frequencia_ponderada(df, n_ultimos)
    prob_tend = probabilidade_tendencia(df, janela_curta=10, janela_longa=min(50, n_ultimos))
    prob_reg = probabilidade_regressao_logistica(df, min(200, n_ultimos))
    
    ranking_final = {}
    detalhes = {}
    
    for num in range(1, 26):
        score = (
            pesos['markov'] * prob_markov.get(num, 0) +
            pesos['frequencia'] * prob_freq.get(num, 0) +
            pesos['tendencia'] * prob_tend.get(num, 0) +
            pesos['regressao'] * prob_reg.get(num, 0)
        )
        ranking_final[num] = score
        detalhes[num] = {
            'markov': round(prob_markov.get(num, 0), 4),
            'frequencia': round(prob_freq.get(num, 0), 4),
            'tendencia': round(prob_tend.get(num, 0), 4),
            'regressao': round(prob_reg.get(num, 0), 4),
            'score_final': round(score, 4)
        }
    
    ranking_ordenado = sorted(ranking_final.items(), key=lambda x: x[1], reverse=True)
    
    return {
        'ranking': ranking_ordenado,
        'detalhes': detalhes,
        'pesos_usados': pesos
    }


def gerar_alertas(previsao):
    ranking = previsao['ranking']
    
    provaveis = [num for num, _ in ranking[:15]]
    neutros = [num for num, _ in ranking[15:20]]
    friissimos = [num for num, _ in ranking[20:]]
    
    return {
        'provaveis_top15': provaveis,
        'neutros': neutros,
        'friissimos': friissimos,
        'sugestao_jogo': sorted(provaveis)
    }


def analisar_bolao(boloes_df, previsao, df_resultados=None):
    if df_resultados is None:
        df_resultados = load_resultados()
    
    ranking_dict = dict(previsao['ranking'])
    
    resultados = []
    
    for _, row in boloes_df.iterrows():
        bolao_id = row.get('bolao_id', 0)
        jogo_id = row.get('jogo_id', 0)
        numeros_str = row.get('numeros', '')
        
        try:
            numeros = [int(n.strip()) for n in str(numeros_str).split(',')]
        except ValueError:
            continue
        
        if len(numeros) < 15:
            continue
        
        numeros = numeros[:15]
        
        score_total = sum(ranking_dict.get(n, 0) for n in numeros)
        score_medio = score_total / len(numeros)
        
        provaveis = previsao['ranking'][:15]
        nums_provaveis = [n for n, _ in provaveis]
        acertos_provaveis = len(set(numeros) & set(nums_provaveis))
        
        friissimos = previsao['ranking'][20:]
        nums_frios = [n for n, _ in friissimos]
        numeros_frios = len(set(numeros) & set(nums_frios))
        
        forca = (score_medio * 100) + (acertos_provaveis * 5) - (numeros_frios * 3)
        
        resultados.append({
            'bolao_id': bolao_id,
            'jogo_id': jogo_id,
            'numeros': ','.join(map(str, sorted(numeros))),
            'score_total': round(score_total, 4),
            'score_medio': round(score_medio, 4),
            'acertos_provaveis': acertos_provaveis,
            'numeros_frios': numeros_frios,
            'forca': round(forca, 2)
        })
    
    df_ranking = pd.DataFrame(resultados)
    if not df_ranking.empty:
        df_ranking = df_ranking.sort_values('forca', ascending=False).reset_index(drop=True)
        df_ranking['posicao'] = range(1, len(df_ranking) + 1)
    
    return df_ranking


def salvar_previsoes(previsao, alertas):
    ensure_data_dir()
    
    dados = {
        'ranking': [(int(n), float(s)) for n, s in previsao['ranking']],
        'detalhes': {str(k): v for k, v in previsao['detalhes'].items()},
        'pesos_usados': previsao['pesos_usados'],
        'alertas': {
            'provaveis_top15': [int(n) for n in alertas['provaveis_top15']],
            'neutros': [int(n) for n in alertas['neutros']],
            'friissimos': [int(n) for n in alertas['friissimos']],
            'sugestao_jogo': [int(n) for n in alertas['sugestao_jogo']]
        }
    }
    
    with open(PREVISOES_JSON, 'w', encoding='utf-8') as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    
    return PREVISOES_JSON


def salvar_ranking_boloes(df_ranking):
    ensure_data_dir()
    df_ranking.to_csv(RANKING_BOLOES_CSV, index=False)
    return RANKING_BOLOES_CSV


def carregar_previsoes():
    if os.path.exists(PREVISOES_JSON):
        with open(PREVISOES_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


if __name__ == "__main__":
    df = load_resultados()
    if not df.empty:
        previsao = gerar_previsao_combinada(df)
        alertas = gerar_alertas(previsao)
        
        print("Top 15 números mais prováveis:")
        for num, score in previsao['ranking'][:15]:
            print(f"  {num:2d}: {score:.4f}")
        
        print(f"\nSugestão de jogo: {alertas['sugestao_jogo']}")
        print(f"Números friíssimos: {alertas['friissimos']}")
        
        salvar_previsoes(previsao, alertas)
        print("\nPrevisões salvas!")
