# Análise Lotofácil - Sistema Avançado

## Visão Geral
Sistema completo de análise estatística e previsão para a Lotofácil, incluindo:
- Scraping robusto de resultados oficiais da Caixa (com fallback e tratamento de erros)
- Análises estatísticas avançadas
- Sistema de previsão com múltiplos métodos (Markov, frequência ponderada, tendência, regressão logística)
- Análise e ranking de bolões por força/probabilidade
- Painel interativo Streamlit com exportação de dados
- Integração completa com Google Sheets
- Scheduler automático diário (06:00 Brasília)

## Estrutura do Projeto

```
├── app.py           # Painel Streamlit (interface principal com abas)
├── scraper.py       # Coleta de dados com fallback e resiliência
├── analysis.py      # Análises estatísticas
├── prediction.py    # Sistema de previsão de probabilidades
├── sheets.py        # Integração Google Sheets completa
├── scheduler.py     # Automatização diária
├── tests.py         # Testes do sistema
├── utils.py         # Funções auxiliares e update_all()
├── data/            # Pasta para armazenar dados
│   ├── resultados.csv     # Resultados dos concursos
│   ├── boloes.csv         # Bolões para análise
│   ├── analise.json       # Análise estatística exportada
│   ├── previsoes.json     # Previsões de probabilidade
│   ├── estatisticas.csv   # Estatísticas por número
│   ├── ranking_boloes.csv # Ranking dos bolões
│   ├── sheets_config.json # Configuração dos IDs das planilhas
│   └── scheduler.log      # Log do scheduler
└── credentials.json # (ignorado) Credenciais Google
```

## Funcionalidades

### Scraper (scraper.py)
- Busca resultados da API oficial da Caixa
- Fallback para API de backup e scraping HTML
- Sistema de retry com múltiplas tentativas
- Continua mesmo se alguns concursos falharem
- Atualização incremental da base de dados

### Análises (analysis.py)
- Frequência dos números
- Números quentes e frios
- Repetição entre concursos
- Análise de pares e triplas
- Análise combinatória (soma, pares/ímpares, baixos/altos)
- Cadeias de Markov (ordem 1)
- Clustering com K-Means

### Previsão (prediction.py)
- Probabilidade por Markov (ordem 1)
- Frequência ponderada com decay temporal
- Análise de tendência (curto vs longo prazo)
- Regressão logística simples
- Ranking combinado com pesos configuráveis
- Alertas: números prováveis, neutros e friíssimos
- Sugestão automática de jogo

### Análise de Bolões
- Leitura de CSV ou Google Sheets
- Cálculo de score por jogo baseado nas previsões
- Ranking por força/probabilidade
- Identificação de números quentes e frios por jogo

### Google Sheets (sheets.py)
- load_credentials(): Carrega credenciais do arquivo JSON
- read_sheet(sheet_id): Lê planilha por ID
- write_sheet(sheet_id, dataframe): Escreve dados em planilha
- append_rows(sheet_id, rows): Adiciona linhas
- sync_predictions_to_sheets(): Envia previsões para Sheets
- sync_rankings_to_sheets(): Envia rankings para Sheets
- load_boloes_from_sheets(): Carrega bolões do Sheets

### Scheduler (scheduler.py)
- Execução automática às 06:00 (Brasília)
- Pipeline completo: scraper → análises → previsões → bolões → Sheets
- Logging em arquivo (data/scheduler.log)
- Pode rodar manualmente: `python scheduler.py`
- Modo loop: `python scheduler.py --loop`

### Testes (tests.py)
- Testes de imports
- Testes de utils
- Testes de analysis
- Testes de prediction
- Testes de sheets
- Testes de update_all
- Executar: `python tests.py`

### Interface (app.py)
Abas disponíveis:
- **Dashboard**: Visão geral e ações rápidas
- **Estatísticas**: Análises detalhadas com sliders
- **Probabilidades**: Sistema de previsão com pesos configuráveis
- **Analisar Bolões**: Ranking de bolões por força
- **Gráficos**: Visualizações interativas
- **Google Sheets**: Configuração e sincronização
- **Configurações**: Atualização e exportação

## Como Usar

1. **Iniciar**: A interface Streamlit abre automaticamente
2. **Criar Base**: Dashboard → "Criar Base Inicial"
3. **Ver Estatísticas**: Aba Estatísticas → selecione análise
4. **Gerar Previsões**: Aba Probabilidades → ajuste pesos → "Gerar Previsões"
5. **Analisar Bolões**: Aba Bolões → carregar CSV → "Analisar Bolões"
6. **Google Sheets**: Aba Google Sheets → configurar IDs → sincronizar
7. **Atualização Completa**: Configurações → "Executar Atualização Completa"

## Função update_all()

Executa automaticamente:
1. Baixa novos concursos
2. Gera análises estatísticas
3. Calcula previsões de probabilidade
4. Analisa bolões (se houver)
5. Salva tudo em CSV e JSON

Pode ser chamada via:
- Botão "Atualizar Tudo" no Dashboard
- Linha de comando: `python utils.py`
- Scheduler automático: `python scheduler.py`

## Exportação

- **previsoes.json**: Ranking de probabilidades e sugestões
- **ranking_boloes.csv**: Ranking dos bolões por força
- **analise.json**: Análise estatística completa
- **estatisticas.csv**: Frequência por número

## Configuração Google Sheets

1. Crie um projeto no Google Cloud Console
2. Ative a API do Google Sheets e Google Drive
3. Crie uma conta de serviço
4. Baixe o arquivo JSON de credenciais
5. Salve como `credentials.json` na raiz do projeto
6. Compartilhe suas planilhas com o email da conta de serviço

## Formato da Planilha de Bolões

A planilha deve ter as colunas:
- `bolao_id`: ID do bolão (número)
- `jogo_id`: ID do jogo dentro do bolão (número)
- `numeros`: números separados por vírgula (ex: 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)

## Preferências do Usuário
- Idioma: Português
- Framework: Streamlit para interface
- Pesos padrão: Markov 30%, Frequência 25%, Tendência 25%, Regressão 20%
- Horário scheduler: 06:00 (Brasília)

## Testes

Execute os testes com:
```bash
python tests.py        # Testes completos
python tests.py --quick # Testes rápidos (sem rede)
python tests.py --live  # Inclui teste ao vivo do scraper
```

## Últimas Alterações
- 10/12/2024: Projeto inicial criado
- 10/12/2024: Adicionado sistema de previsão com múltiplos métodos
- 10/12/2024: Adicionado módulo de análise de bolões com ranking
- 10/12/2024: Scraper otimizado com fallback e resiliência
- 10/12/2024: Interface redesenhada com abas e controles interativos
- 10/12/2024: Adicionada função update_all() para atualização automática
- 10/12/2024: Adicionado scheduler automático diário
- 10/12/2024: Integração completa com Google Sheets
- 10/12/2024: Adicionados testes do sistema
