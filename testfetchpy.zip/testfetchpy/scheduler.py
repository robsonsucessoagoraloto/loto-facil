#!/usr/bin/env python3
"""
Scheduler para atualização automática diária da Lotofácil.

Este script executa o pipeline completo de atualização:
1. Baixa novos concursos
2. Gera análises estatísticas
3. Calcula previsões de probabilidade
4. Analisa bolões (se houver)
5. Sincroniza com Google Sheets (se configurado)

Pode ser executado:
- Manualmente: python scheduler.py
- Via cron/agendador: configurar para rodar às 06:00 (Brasília)
"""

import os
import sys
import logging
from datetime import datetime
import pytz

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('data/scheduler.log', mode='a')
    ]
)
logger = logging.getLogger(__name__)

TIMEZONE_BRASILIA = pytz.timezone('America/Sao_Paulo')


def get_brasilia_time():
    return datetime.now(TIMEZONE_BRASILIA)


def run_update():
    logger.info("=" * 60)
    logger.info(f"INICIANDO ATUALIZAÇÃO - {get_brasilia_time().strftime('%Y-%m-%d %H:%M:%S')} (Brasília)")
    logger.info("=" * 60)
    
    try:
        from utils import update_all
        result = update_all()
        
        if result:
            logger.info("Pipeline de atualização concluído com sucesso!")
            
            try:
                from sheets import sync_all_to_sheets, verificar_credenciais
                if verificar_credenciais():
                    logger.info("Sincronizando com Google Sheets...")
                    sync_all_to_sheets()
                    logger.info("Sincronização com Sheets concluída!")
                else:
                    logger.info("Credenciais do Google Sheets não configuradas, pulando sincronização.")
            except Exception as e:
                logger.warning(f"Erro na sincronização com Sheets: {e}")
            
            return True
        else:
            logger.error("Falha no pipeline de atualização")
            return False
            
    except Exception as e:
        logger.error(f"Erro durante a atualização: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False


def should_run_now(target_hour=6, target_minute=0):
    now = get_brasilia_time()
    return now.hour == target_hour and now.minute == target_minute


def run_scheduler_loop():
    """Loop contínuo que verifica se deve executar às 06:00 (Brasília)"""
    import time
    
    logger.info("Scheduler iniciado. Aguardando horário de execução (06:00 Brasília)...")
    
    last_run_date = None
    
    while True:
        now = get_brasilia_time()
        current_date = now.date()
        
        if now.hour == 6 and now.minute < 5 and last_run_date != current_date:
            logger.info("Horário de execução atingido!")
            run_update()
            last_run_date = current_date
            
        time.sleep(60)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Scheduler de atualização Lotofácil')
    parser.add_argument('--now', action='store_true', help='Executar atualização imediatamente')
    parser.add_argument('--loop', action='store_true', help='Iniciar loop de scheduler (06:00 diário)')
    
    args = parser.parse_args()
    
    if args.loop:
        run_scheduler_loop()
    else:
        success = run_update()
        sys.exit(0 if success else 1)
