import requests
from bs4 import BeautifulSoup
import pandas as pd
import json
import re
import time
import logging
from utils import save_resultados, RESULTADOS_FILE, ensure_data_dir
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_URL = "https://loterias.caixa.gov.br/Paginas/Lotofacil.aspx"
API_URL = "https://servicebus2.caixa.gov.br/portaldeloterias/api/lotofacil"
API_URL_BACKUP = "https://loteriascaixa-api.herokuapp.com/api/lotofacil"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/html, */*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
}


class ScraperError(Exception):
    pass


def fetch_with_retry(url, max_retries=3, delay=2):
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=HEADERS, timeout=30)
            if response.status_code == 200:
                return response
            elif response.status_code == 404:
                logger.warning(f"Concurso não encontrado: {url}")
                return None
            else:
                logger.warning(f"Tentativa {attempt + 1}: Status {response.status_code}")
        except requests.exceptions.Timeout:
            logger.warning(f"Tentativa {attempt + 1}: Timeout")
        except requests.exceptions.ConnectionError:
            logger.warning(f"Tentativa {attempt + 1}: Erro de conexão")
        except Exception as e:
            logger.warning(f"Tentativa {attempt + 1}: Erro {e}")
        
        if attempt < max_retries - 1:
            time.sleep(delay * (attempt + 1))
    
    return None


def fetch_from_html_fallback(concurso=None):
    try:
        url = BASE_URL
        if concurso:
            url = f"{BASE_URL}?sorteio={concurso}"
        
        response = fetch_with_retry(url)
        if not response:
            return None
        
        soup = BeautifulSoup(response.text, 'lxml')
        
        dezenas = []
        dezenas_container = soup.find('ul', class_='numbers')
        if dezenas_container:
            for li in dezenas_container.find_all('li'):
                try:
                    dezenas.append(int(li.text.strip()))
                except ValueError:
                    continue
        
        if not dezenas:
            dezenas_spans = soup.find_all('span', class_='dezena')
            for span in dezenas_spans:
                try:
                    dezenas.append(int(span.text.strip()))
                except ValueError:
                    continue
        
        if len(dezenas) >= 15:
            concurso_elem = soup.find('span', class_='ng-binding')
            concurso_num = concurso or 0
            if concurso_elem:
                match = re.search(r'\d+', concurso_elem.text)
                if match:
                    concurso_num = int(match.group())
            
            return {
                'Concurso': concurso_num,
                'Data': '',
                **{f'N{i}': dezenas[i-1] for i in range(1, 16)},
                'Acumulou': False,
                'Premio15': 0
            }
    except Exception as e:
        logger.error(f"Erro no fallback HTML: {e}")
    
    return None


def fetch_ultimo_resultado():
    response = fetch_with_retry(API_URL)
    if response:
        try:
            data = response.json()
            return parse_api_response(data)
        except json.JSONDecodeError:
            logger.warning("Erro ao decodificar JSON da API principal")
    
    logger.info("Tentando API de backup...")
    response = fetch_with_retry(f"{API_URL_BACKUP}/latest")
    if response:
        try:
            data = response.json()
            return parse_api_response_backup(data)
        except json.JSONDecodeError:
            pass
    
    logger.info("Tentando fallback HTML...")
    return fetch_from_html_fallback()


def fetch_resultado_por_concurso(concurso):
    url = f"{API_URL}/{concurso}"
    response = fetch_with_retry(url)
    if response:
        try:
            data = response.json()
            return parse_api_response(data)
        except json.JSONDecodeError:
            logger.warning(f"Erro JSON para concurso {concurso}")
    
    response = fetch_with_retry(f"{API_URL_BACKUP}/{concurso}")
    if response:
        try:
            data = response.json()
            return parse_api_response_backup(data)
        except json.JSONDecodeError:
            pass
    
    return fetch_from_html_fallback(concurso)


def parse_api_response(data):
    if not data:
        return None
    
    try:
        resultado = {
            'Concurso': data.get('numero', 0),
            'Data': data.get('dataApuracao', ''),
        }
        
        dezenas = data.get('listaDezenas', [])
        if len(dezenas) < 15:
            logger.warning(f"Concurso {resultado['Concurso']}: apenas {len(dezenas)} dezenas")
            return None
        
        for i, dezena in enumerate(dezenas[:15], 1):
            resultado[f'N{i}'] = int(dezena)
        
        resultado['Acumulou'] = data.get('acumulado', False)
        
        rateio = data.get('listaRateioPremio', [])
        resultado['Premio15'] = rateio[0].get('valorPremio', 0) if rateio else 0
        
        return resultado
    except Exception as e:
        logger.error(f"Erro ao parsear resposta: {e}")
        return None


def parse_api_response_backup(data):
    if not data:
        return None
    
    try:
        resultado = {
            'Concurso': data.get('concurso', 0),
            'Data': data.get('data', ''),
        }
        
        dezenas = data.get('dezenas', [])
        if len(dezenas) < 15:
            return None
        
        for i, dezena in enumerate(dezenas[:15], 1):
            resultado[f'N{i}'] = int(dezena)
        
        resultado['Acumulou'] = data.get('acumulado', False)
        resultado['Premio15'] = data.get('premiacoes', [{}])[0].get('premio', 0) if data.get('premiacoes') else 0
        
        return resultado
    except Exception as e:
        logger.error(f"Erro ao parsear backup: {e}")
        return None


def fetch_ultimos_resultados(quantidade=100, continuar_com_falhas=True):
    resultados = []
    falhas = []
    
    ultimo = fetch_ultimo_resultado()
    if not ultimo:
        logger.error("Não foi possível obter o último resultado de nenhuma fonte")
        return pd.DataFrame(), falhas
    
    resultados.append(ultimo)
    ultimo_concurso = ultimo['Concurso']
    
    logger.info(f"Último concurso: {ultimo_concurso}")
    logger.info(f"Buscando os últimos {quantidade} concursos...")
    
    for i in range(1, quantidade):
        concurso = ultimo_concurso - i
        if concurso < 1:
            break
        
        resultado = fetch_resultado_por_concurso(concurso)
        if resultado:
            resultados.append(resultado)
        else:
            falhas.append(concurso)
            if not continuar_com_falhas and len(falhas) > 5:
                logger.error(f"Muitas falhas consecutivas. Parando.")
                break
        
        if (i + 1) % 10 == 0:
            logger.info(f"Progresso: {i + 1}/{quantidade} (falhas: {len(falhas)})")
        
        time.sleep(0.1)
    
    df = pd.DataFrame(resultados)
    if not df.empty:
        df = df.sort_values('Concurso', ascending=False).reset_index(drop=True)
    
    if falhas:
        logger.warning(f"Concursos com falha: {falhas}")
    
    return df, falhas


def atualizar_resultados(quantidade=50):
    ensure_data_dir()
    
    if os.path.exists(RESULTADOS_FILE):
        df_existente = pd.read_csv(RESULTADOS_FILE)
        ultimo_salvo = df_existente['Concurso'].max() if not df_existente.empty else 0
    else:
        df_existente = pd.DataFrame()
        ultimo_salvo = 0
    
    ultimo = fetch_ultimo_resultado()
    if not ultimo:
        logger.error("Não foi possível obter dados atualizados")
        return df_existente, []
    
    ultimo_concurso = ultimo['Concurso']
    
    if ultimo_concurso <= ultimo_salvo:
        logger.info("Dados já estão atualizados")
        return df_existente, []
    
    novos_resultados = []
    falhas = []
    
    for concurso in range(ultimo_salvo + 1, ultimo_concurso + 1):
        resultado = fetch_resultado_por_concurso(concurso)
        if resultado:
            novos_resultados.append(resultado)
        else:
            falhas.append(concurso)
        time.sleep(0.1)
    
    if novos_resultados:
        df_novos = pd.DataFrame(novos_resultados)
        df_completo = pd.concat([df_existente, df_novos], ignore_index=True)
        df_completo = df_completo.drop_duplicates(subset=['Concurso'])
        df_completo = df_completo.sort_values('Concurso', ascending=False).reset_index(drop=True)
        save_resultados(df_completo)
        logger.info(f"Adicionados {len(novos_resultados)} novos concursos")
        return df_completo, falhas
    
    return df_existente, falhas


def criar_base_inicial(quantidade=100):
    logger.info(f"Criando base inicial com {quantidade} concursos...")
    df, falhas = fetch_ultimos_resultados(quantidade, continuar_com_falhas=True)
    if not df.empty:
        save_resultados(df)
        logger.info(f"Base criada com {len(df)} concursos (falhas: {len(falhas)})")
    return df


def retry_falhas(falhas):
    resultados = []
    ainda_falhas = []
    
    for concurso in falhas:
        resultado = fetch_resultado_por_concurso(concurso)
        if resultado:
            resultados.append(resultado)
        else:
            ainda_falhas.append(concurso)
        time.sleep(0.5)
    
    return resultados, ainda_falhas


if __name__ == "__main__":
    df = criar_base_inicial(100)
    print(df.head())
