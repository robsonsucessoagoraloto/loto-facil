"""
Módulo de integração com Google Sheets.

Suporta:
- Credenciais via arquivo JSON (credentials.json)
- Leitura e escrita de planilhas por ID ou nome
- Sincronização automática de previsões e rankings
"""

import gspread
from google.oauth2.service_account import Credentials
import pandas as pd
import json
import os
from utils import ensure_data_dir, PREVISOES_JSON, RANKING_BOLOES_CSV, load_previsoes_json, load_ranking_boloes

CREDENTIALS_FILE = "credentials.json"
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]

CONFIG_FILE = "data/sheets_config.json"


def load_credentials():
    if not os.path.exists(CREDENTIALS_FILE):
        raise FileNotFoundError(
            f"Arquivo de credenciais '{CREDENTIALS_FILE}' não encontrado.\n"
            "Para usar esta função:\n"
            "1. Crie um projeto no Google Cloud Console\n"
            "2. Ative a API do Google Sheets e Google Drive\n"
            "3. Crie uma conta de serviço\n"
            "4. Baixe o arquivo JSON de credenciais\n"
            "5. Renomeie para 'credentials.json' e coloque na pasta do projeto\n"
            "6. Compartilhe suas planilhas com o email da conta de serviço"
        )
    
    credentials = Credentials.from_service_account_file(
        CREDENTIALS_FILE, 
        scopes=SCOPES
    )
    return credentials


def get_client():
    credentials = load_credentials()
    client = gspread.authorize(credentials)
    return client


def verificar_credenciais():
    return os.path.exists(CREDENTIALS_FILE)


def get_service_account_email():
    if not verificar_credenciais():
        return None
    
    try:
        with open(CREDENTIALS_FILE, 'r') as f:
            creds = json.load(f)
            return creds.get('client_email', None)
    except:
        return None


def load_sheets_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {
        'boloes_sheet_id': '',
        'previsoes_sheet_id': '',
        'rankings_sheet_id': ''
    }


def save_sheets_config(config):
    ensure_data_dir()
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def read_sheet(sheet_id, worksheet_name=None):
    client = get_client()
    
    try:
        spreadsheet = client.open_by_key(sheet_id)
    except gspread.SpreadsheetNotFound:
        raise ValueError(f"Planilha com ID '{sheet_id}' não encontrada. Verifique se o ID está correto e se a planilha foi compartilhada com a conta de serviço.")
    except gspread.exceptions.APIError as e:
        raise ValueError(f"Erro de API: {e}. Verifique se a planilha foi compartilhada com a conta de serviço.")
    
    if worksheet_name:
        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
        except gspread.WorksheetNotFound:
            worksheet = spreadsheet.sheet1
    else:
        worksheet = spreadsheet.sheet1
    
    data = worksheet.get_all_records()
    df = pd.DataFrame(data)
    
    return df


def write_sheet(sheet_id, dataframe, worksheet_name=None):
    client = get_client()
    
    try:
        spreadsheet = client.open_by_key(sheet_id)
    except gspread.SpreadsheetNotFound:
        raise ValueError(f"Planilha com ID '{sheet_id}' não encontrada")
    
    if worksheet_name:
        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
            worksheet.clear()
        except gspread.WorksheetNotFound:
            worksheet = spreadsheet.add_worksheet(title=worksheet_name, rows=1000, cols=30)
    else:
        worksheet = spreadsheet.sheet1
        worksheet.clear()
    
    if dataframe.empty:
        return spreadsheet.url
    
    header = dataframe.columns.tolist()
    values = dataframe.astype(str).values.tolist()
    data = [header] + values
    
    worksheet.update(range_name='A1', values=data)
    
    return spreadsheet.url


def append_rows(sheet_id, rows, worksheet_name=None):
    client = get_client()
    
    try:
        spreadsheet = client.open_by_key(sheet_id)
    except gspread.SpreadsheetNotFound:
        raise ValueError(f"Planilha com ID '{sheet_id}' não encontrada")
    
    if worksheet_name:
        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
        except gspread.WorksheetNotFound:
            worksheet = spreadsheet.add_worksheet(title=worksheet_name, rows=1000, cols=30)
    else:
        worksheet = spreadsheet.sheet1
    
    if isinstance(rows, pd.DataFrame):
        rows = rows.astype(str).values.tolist()
    
    worksheet.append_rows(rows)
    
    return spreadsheet.url


def sync_predictions_to_sheets(sheet_id=None):
    if sheet_id is None:
        config = load_sheets_config()
        sheet_id = config.get('previsoes_sheet_id', '')
    
    if not sheet_id:
        raise ValueError("ID da planilha de previsões não configurado")
    
    previsoes = load_previsoes_json()
    if not previsoes:
        raise ValueError("Nenhuma previsão encontrada. Execute update_all() primeiro.")
    
    ranking_data = []
    for num, score in previsoes['ranking']:
        detalhes = previsoes['detalhes'].get(str(num), {})
        ranking_data.append({
            'Número': num,
            'Score Final': score,
            'Markov': detalhes.get('markov', 0),
            'Frequência': detalhes.get('frequencia', 0),
            'Tendência': detalhes.get('tendencia', 0),
            'Regressão': detalhes.get('regressao', 0)
        })
    
    df_ranking = pd.DataFrame(ranking_data)
    
    client = get_client()
    spreadsheet = client.open_by_key(sheet_id)
    
    try:
        ws_ranking = spreadsheet.worksheet("Ranking")
        ws_ranking.clear()
    except gspread.WorksheetNotFound:
        ws_ranking = spreadsheet.add_worksheet(title="Ranking", rows=30, cols=10)
    
    data = [df_ranking.columns.tolist()] + df_ranking.astype(str).values.tolist()
    ws_ranking.update(range_name='A1', values=data)
    
    try:
        ws_alertas = spreadsheet.worksheet("Alertas")
        ws_alertas.clear()
    except gspread.WorksheetNotFound:
        ws_alertas = spreadsheet.add_worksheet(title="Alertas", rows=30, cols=20)
    
    alertas = previsoes.get('alertas', {})
    alertas_data = [
        ["Categoria", "Números"],
        ["Top 15 Prováveis", ', '.join(map(str, alertas.get('provaveis_top15', [])))],
        ["Neutros", ', '.join(map(str, alertas.get('neutros', [])))],
        ["Friíssimos", ', '.join(map(str, alertas.get('friissimos', [])))],
        ["Sugestão de Jogo", ', '.join(map(str, alertas.get('sugestao_jogo', [])))]
    ]
    ws_alertas.update(range_name='A1', values=alertas_data)
    
    return spreadsheet.url


def sync_rankings_to_sheets(sheet_id=None):
    if sheet_id is None:
        config = load_sheets_config()
        sheet_id = config.get('rankings_sheet_id', '')
    
    if not sheet_id:
        raise ValueError("ID da planilha de rankings não configurado")
    
    df_ranking = load_ranking_boloes()
    if df_ranking.empty:
        raise ValueError("Nenhum ranking de bolões encontrado. Analise os bolões primeiro.")
    
    url = write_sheet(sheet_id, df_ranking, "Ranking Bolões")
    
    return url


def load_boloes_from_sheets(sheet_id=None):
    if sheet_id is None:
        config = load_sheets_config()
        sheet_id = config.get('boloes_sheet_id', '')
    
    if not sheet_id:
        raise ValueError("ID da planilha de bolões não configurado")
    
    df = read_sheet(sheet_id)
    
    required_cols = ['bolao_id', 'jogo_id', 'numeros']
    missing = [col for col in required_cols if col not in df.columns]
    
    if missing:
        alt_cols = df.columns.tolist()
        raise ValueError(
            f"Colunas obrigatórias não encontradas: {missing}\n"
            f"Colunas disponíveis: {alt_cols}\n"
            f"A planilha deve ter as colunas: bolao_id, jogo_id, numeros"
        )
    
    return df


def sync_all_to_sheets():
    config = load_sheets_config()
    results = {}
    
    if config.get('previsoes_sheet_id'):
        try:
            url = sync_predictions_to_sheets(config['previsoes_sheet_id'])
            results['previsoes'] = {'success': True, 'url': url}
        except Exception as e:
            results['previsoes'] = {'success': False, 'error': str(e)}
    
    if config.get('rankings_sheet_id'):
        try:
            url = sync_rankings_to_sheets(config['rankings_sheet_id'])
            results['rankings'] = {'success': True, 'url': url}
        except Exception as e:
            results['rankings'] = {'success': False, 'error': str(e)}
    
    return results


def ler_boloes_sheets(spreadsheet_name, worksheet_name="Bolões"):
    client = get_client()
    
    try:
        spreadsheet = client.open(spreadsheet_name)
    except gspread.SpreadsheetNotFound:
        raise ValueError(f"Planilha '{spreadsheet_name}' não encontrada")
    
    try:
        worksheet = spreadsheet.worksheet(worksheet_name)
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.sheet1
    
    data = worksheet.get_all_records()
    df = pd.DataFrame(data)
    
    return df


def salvar_para_sheets(df, spreadsheet_name, worksheet_name="Dados"):
    client = get_client()
    
    try:
        spreadsheet = client.open(spreadsheet_name)
    except gspread.SpreadsheetNotFound:
        spreadsheet = client.create(spreadsheet_name)
    
    try:
        worksheet = spreadsheet.worksheet(worksheet_name)
        worksheet.clear()
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(title=worksheet_name, rows=1000, cols=20)
    
    data = [df.columns.tolist()] + df.astype(str).values.tolist()
    worksheet.update(range_name='A1', values=data)
    
    return spreadsheet.url


def listar_planilhas():
    client = get_client()
    spreadsheets = client.openall()
    return [
        {'nome': s.title, 'id': s.id, 'url': s.url}
        for s in spreadsheets
    ]


def criar_planilha_exemplo():
    client = get_client()
    
    spreadsheet = client.create("Lotofacil_Boloes")
    worksheet = spreadsheet.sheet1
    worksheet.update_title("Bolões")
    
    cabecalho = ['bolao_id', 'jogo_id', 'numeros']
    dados_exemplo = [
        [1, 1, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15'],
        [1, 2, '5,6,7,8,9,10,11,12,13,14,15,16,17,18,19'],
        [2, 1, '1,3,5,7,9,11,13,15,17,19,21,23,24,25'],
    ]
    
    worksheet.update(range_name='A1', values=[cabecalho] + dados_exemplo)
    
    return {'id': spreadsheet.id, 'url': spreadsheet.url}


if __name__ == "__main__":
    if verificar_credenciais():
        print("✅ Credenciais encontradas!")
        email = get_service_account_email()
        if email:
            print(f"📧 Email da conta de serviço: {email}")
            print("   (Compartilhe suas planilhas com este email)")
        
        try:
            planilhas = listar_planilhas()
            print(f"\n📊 Planilhas disponíveis ({len(planilhas)}):")
            for p in planilhas[:5]:
                print(f"   - {p['nome']} (ID: {p['id']})")
            if len(planilhas) > 5:
                print(f"   ... e mais {len(planilhas) - 5}")
        except Exception as e:
            print(f"❌ Erro ao listar planilhas: {e}")
    else:
        print("❌ Credenciais não encontradas.")
        print("\nPara configurar:")
        print("1. Crie um projeto no Google Cloud Console")
        print("2. Ative a API do Google Sheets e Google Drive")
        print("3. Crie uma conta de serviço e baixe o JSON")
        print("4. Salve como 'credentials.json' na pasta do projeto")
        print("5. Compartilhe suas planilhas com o email da conta de serviço")
