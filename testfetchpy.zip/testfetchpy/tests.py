#!/usr/bin/env python3
"""
Testes simples para o sistema Lotofácil.

Execute com: python tests.py
"""

import os
import sys
import json
import pandas as pd
from datetime import datetime

class TestResult:
    def __init__(self, name, passed, message=""):
        self.name = name
        self.passed = passed
        self.message = message


class TestRunner:
    def __init__(self):
        self.results = []
    
    def add_result(self, name, passed, message=""):
        self.results.append(TestResult(name, passed, message))
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {name}")
        if message and not passed:
            print(f"       {message}")
    
    def summary(self):
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        failed = total - passed
        
        print("\n" + "=" * 50)
        print(f"RESULTADOS: {passed}/{total} testes passaram")
        if failed > 0:
            print(f"Falhas: {failed}")
        print("=" * 50)
        
        return failed == 0


def test_imports():
    runner = TestRunner()
    
    try:
        from utils import load_resultados, save_resultados, ensure_data_dir
        runner.add_result("Import utils", True)
    except Exception as e:
        runner.add_result("Import utils", False, str(e))
    
    try:
        from scraper import fetch_ultimo_resultado, fetch_resultado_por_concurso
        runner.add_result("Import scraper", True)
    except Exception as e:
        runner.add_result("Import scraper", False, str(e))
    
    try:
        from analysis import frequencia_numeros, numeros_quentes_frios
        runner.add_result("Import analysis", True)
    except Exception as e:
        runner.add_result("Import analysis", False, str(e))
    
    try:
        from prediction import gerar_previsao_combinada, gerar_alertas
        runner.add_result("Import prediction", True)
    except Exception as e:
        runner.add_result("Import prediction", False, str(e))
    
    try:
        from sheets import verificar_credenciais, load_sheets_config
        runner.add_result("Import sheets", True)
    except Exception as e:
        runner.add_result("Import sheets", False, str(e))
    
    try:
        from scheduler import run_update
        runner.add_result("Import scheduler", True)
    except Exception as e:
        runner.add_result("Import scheduler", False, str(e))
    
    return runner


def test_utils():
    runner = TestRunner()
    
    from utils import ensure_data_dir, DATA_DIR
    
    try:
        ensure_data_dir()
        runner.add_result("ensure_data_dir()", os.path.exists(DATA_DIR))
    except Exception as e:
        runner.add_result("ensure_data_dir()", False, str(e))
    
    try:
        from utils import create_sample_boloes, load_boloes
        df = create_sample_boloes()
        runner.add_result("create_sample_boloes()", len(df) > 0)
        
        df_loaded = load_boloes()
        runner.add_result("load_boloes()", len(df_loaded) > 0)
    except Exception as e:
        runner.add_result("boloes functions", False, str(e))
    
    return runner


def test_scraper():
    runner = TestRunner()
    
    from scraper import fetch_ultimo_resultado
    
    try:
        resultado = fetch_ultimo_resultado()
        if resultado:
            runner.add_result("fetch_ultimo_resultado()", True)
            runner.add_result("Concurso válido", resultado['Concurso'] > 0)
            
            cols = [f'N{i}' for i in range(1, 16)]
            has_all = all(col in resultado for col in cols)
            runner.add_result("15 dezenas presentes", has_all)
        else:
            runner.add_result("fetch_ultimo_resultado()", False, "Retornou None")
    except Exception as e:
        runner.add_result("fetch_ultimo_resultado()", False, str(e))
    
    return runner


def test_analysis():
    runner = TestRunner()
    
    from analysis import frequencia_numeros, numeros_quentes_frios, analise_combinatoria
    
    df = pd.DataFrame({
        'Concurso': [1, 2, 3],
        'Data': ['01/01/2024', '02/01/2024', '03/01/2024'],
        **{f'N{i}': [i, i+1, i+2] for i in range(1, 16)}
    })
    
    try:
        freq = frequencia_numeros(df)
        runner.add_result("frequencia_numeros()", len(freq) > 0)
    except Exception as e:
        runner.add_result("frequencia_numeros()", False, str(e))
    
    try:
        qf = numeros_quentes_frios(df, 3)
        runner.add_result("numeros_quentes_frios()", 'quentes' in qf and 'frios' in qf)
    except Exception as e:
        runner.add_result("numeros_quentes_frios()", False, str(e))
    
    try:
        comb = analise_combinatoria(df)
        runner.add_result("analise_combinatoria()", 'soma' in comb)
    except Exception as e:
        runner.add_result("analise_combinatoria()", False, str(e))
    
    return runner


def test_prediction():
    runner = TestRunner()
    
    from prediction import gerar_previsao_combinada, gerar_alertas, analisar_bolao
    
    df = pd.DataFrame({
        'Concurso': list(range(1, 51)),
        'Data': ['01/01/2024'] * 50,
        **{f'N{i}': [(j % 25) + 1 for j in range(i, i+50)] for i in range(1, 16)}
    })
    
    try:
        previsao = gerar_previsao_combinada(df, n_ultimos=50)
        runner.add_result("gerar_previsao_combinada()", 'ranking' in previsao)
        runner.add_result("Ranking tem 25 números", len(previsao['ranking']) == 25)
    except Exception as e:
        runner.add_result("gerar_previsao_combinada()", False, str(e))
    
    try:
        alertas = gerar_alertas(previsao)
        runner.add_result("gerar_alertas()", 'provaveis_top15' in alertas)
        runner.add_result("15 números prováveis", len(alertas['provaveis_top15']) == 15)
        runner.add_result("Sugestão de jogo", len(alertas['sugestao_jogo']) == 15)
    except Exception as e:
        runner.add_result("gerar_alertas()", False, str(e))
    
    try:
        boloes = pd.DataFrame({
            'bolao_id': [1, 1],
            'jogo_id': [1, 2],
            'numeros': ['1,2,3,4,5,6,7,8,9,10,11,12,13,14,15', '5,6,7,8,9,10,11,12,13,14,15,16,17,18,19']
        })
        ranking = analisar_bolao(boloes, previsao, df)
        runner.add_result("analisar_bolao()", len(ranking) == 2)
        runner.add_result("Ranking tem coluna forca", 'forca' in ranking.columns)
    except Exception as e:
        runner.add_result("analisar_bolao()", False, str(e))
    
    return runner


def test_sheets():
    runner = TestRunner()
    
    from sheets import verificar_credenciais, load_sheets_config, save_sheets_config
    
    try:
        has_creds = verificar_credenciais()
        runner.add_result("verificar_credenciais()", True, f"Credenciais: {'Sim' if has_creds else 'Não'}")
    except Exception as e:
        runner.add_result("verificar_credenciais()", False, str(e))
    
    try:
        config = load_sheets_config()
        runner.add_result("load_sheets_config()", isinstance(config, dict))
    except Exception as e:
        runner.add_result("load_sheets_config()", False, str(e))
    
    try:
        test_config = {
            'boloes_sheet_id': 'test_id_1',
            'previsoes_sheet_id': 'test_id_2',
            'rankings_sheet_id': 'test_id_3'
        }
        save_sheets_config(test_config)
        loaded = load_sheets_config()
        runner.add_result("save_sheets_config()", loaded == test_config)
        
        save_sheets_config({'boloes_sheet_id': '', 'previsoes_sheet_id': '', 'rankings_sheet_id': ''})
    except Exception as e:
        runner.add_result("save_sheets_config()", False, str(e))
    
    if verificar_credenciais():
        try:
            from sheets import get_client, get_service_account_email
            email = get_service_account_email()
            runner.add_result("get_service_account_email()", email is not None)
            
            client = get_client()
            runner.add_result("get_client()", client is not None)
        except Exception as e:
            runner.add_result("Conexão com Google", False, str(e))
    else:
        runner.add_result("Conexão com Google", True, "Pulado (sem credenciais)")
    
    return runner


def test_update_all():
    runner = TestRunner()
    
    try:
        from utils import update_all, load_resultados
        
        df_before = load_resultados()
        has_data = not df_before.empty
        
        if has_data:
            runner.add_result("Dados pré-existentes", True)
        else:
            runner.add_result("Dados pré-existentes", True, "Nenhum dado, update_all criará")
        
        runner.add_result("update_all() disponível", True)
        
    except Exception as e:
        runner.add_result("test_update_all()", False, str(e))
    
    return runner


def run_all_tests():
    print("=" * 50)
    print("TESTES DO SISTEMA LOTOFÁCIL")
    print(f"Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    
    all_passed = True
    
    print("\n📦 Testes de Import:")
    print("-" * 30)
    if not test_imports().summary():
        all_passed = False
    
    print("\n🔧 Testes de Utils:")
    print("-" * 30)
    if not test_utils().summary():
        all_passed = False
    
    print("\n📊 Testes de Analysis:")
    print("-" * 30)
    if not test_analysis().summary():
        all_passed = False
    
    print("\n🎯 Testes de Prediction:")
    print("-" * 30)
    if not test_prediction().summary():
        all_passed = False
    
    print("\n📋 Testes de Sheets:")
    print("-" * 30)
    if not test_sheets().summary():
        all_passed = False
    
    print("\n🔄 Testes de Update:")
    print("-" * 30)
    if not test_update_all().summary():
        all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 TODOS OS TESTES PASSARAM!")
    else:
        print("⚠️  ALGUNS TESTES FALHARAM")
    print("=" * 50)
    
    return all_passed


def test_scraper_live():
    """Teste ao vivo do scraper (requer internet)"""
    print("\n🌐 Teste ao vivo do Scraper:")
    print("-" * 30)
    runner = TestRunner()
    
    runner = test_scraper()
    runner.summary()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Testes do sistema Lotofácil')
    parser.add_argument('--live', action='store_true', help='Incluir teste ao vivo do scraper')
    parser.add_argument('--quick', action='store_true', help='Apenas testes rápidos (sem rede)')
    
    args = parser.parse_args()
    
    if args.quick:
        print("Modo rápido (sem testes de rede)")
        test_imports().summary()
        test_utils().summary()
        test_analysis().summary()
        test_prediction().summary()
    else:
        success = run_all_tests()
        
        if args.live:
            test_scraper_live()
        
        sys.exit(0 if success else 1)
