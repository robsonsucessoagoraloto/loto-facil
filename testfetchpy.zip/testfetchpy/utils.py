import pandas as pd
import json
import os
from datetime import datetime

DATA_DIR = "data"
RESULTADOS_FILE = os.path.join(DATA_DIR, "resultados.csv")
BOLOES_FILE = os.path.join(DATA_DIR, "boloes.csv")
ANALISE_JSON = os.path.join(DATA_DIR, "analise.json")
ESTATISTICAS_CSV = os.path.join(DATA_DIR, "estatisticas.csv")
PREVISOES_JSON = os.path.join(DATA_DIR, "previsoes.json")
RANKING_BOLOES_CSV = os.path.join(DATA_DIR, "ranking_boloes.csv")


def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)


def load_resultados():
    if os.path.exists(RESULTADOS_FILE):
        return pd.read_csv(RESULTADOS_FILE)
    return pd.DataFrame()


def save_resultados(df):
    ensure_data_dir()
    df.to_csv(RESULTADOS_FILE, index=False)


def load_boloes():
    if os.path.exists(BOLOES_FILE):
        return pd.read_csv(BOLOES_FILE)
    return pd.DataFrame()


def save_boloes(df):
    ensure_data_dir()
    df.to_csv(BOLOES_FILE, index=False)


def save_analise_json(data):
    ensure_data_dir()
    with open(ANALISE_JSON, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_analise_json():
    if os.path.exists(ANALISE_JSON):
        with open(ANALISE_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def save_estatisticas_csv(df):
    ensure_data_dir()
    df.to_csv(ESTATISTICAS_CSV, index=False)


def save_previsoes_json(data):
    ensure_data_dir()
    with open(PREVISOES_JSON, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_previsoes_json():
    if os.path.exists(PREVISOES_JSON):
        with open(PREVISOES_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def save_ranking_boloes(df):
    ensure_data_dir()
    df.to_csv(RANKING_BOLOES_CSV, index=False)


def load_ranking_boloes():
    if os.path.exists(RANKING_BOLOES_CSV):
        return pd.read_csv(RANKING_BOLOES_CSV)
    return pd.DataFrame()


def get_numeros_from_row(row):
    cols = [f'N{i}' for i in range(1, 16)]
    return [int(row[col]) for col in cols if col in row]


def format_date(date_str):
    try:
        return datetime.strptime(date_str, "%d/%m/%Y").strftime("%Y-%m-%d")
    except:
        return date_str


def create_sample_boloes():
    ensure_data_dir()
    sample_data = {
        'bolao_id': [1, 1, 1, 2, 2, 2, 3, 3],
        'jogo_id': [1, 2, 3, 1, 2, 3, 1, 2],
        'numeros': [
            '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15',
            '5,6,7,8,9,10,11,12,13,14,15,16,17,18,19',
            '2,4,6,8,10,12,14,16,18,20,22,23,24,25',
            '1,3,5,7,9,11,13,15,17,19,21,23,24,25',
            '3,5,7,9,11,13,15,17,19,21,22,23,24,25',
            '1,2,3,5,8,10,12,14,16,18,20,21,23,24,25',
            '4,5,6,7,8,9,10,11,12,13,14,15,16,17,18',
            '1,4,7,10,13,14,15,16,17,18,19,20,21,22,25'
        ]
    }
    df = pd.DataFrame(sample_data)
    df.to_csv(BOLOES_FILE, index=False)
    return df


def update_all():
    from scraper import atualizar_resultados
    from analysis import gerar_analise_completa
    from prediction import gerar_previsao_combinada, gerar_alertas, salvar_previsoes, analisar_bolao, salvar_ranking_boloes
    
    print("=" * 50)
    print("ATUALIZAÇÃO COMPLETA")
    print("=" * 50)
    
    print("\n1. Atualizando resultados...")
    df, falhas = atualizar_resultados(50)
    print(f"   Total de concursos: {len(df)}")
    if falhas:
        print(f"   Falhas: {len(falhas)}")
    
    if df.empty:
        print("   Nenhum dado disponível!")
        return None
    
    print("\n2. Gerando análises estatísticas...")
    analise = gerar_analise_completa(df)
    print(f"   Análise salva em {ANALISE_JSON}")
    
    print("\n3. Gerando previsões...")
    previsao = gerar_previsao_combinada(df)
    alertas = gerar_alertas(previsao)
    salvar_previsoes(previsao, alertas)
    print(f"   Previsões salvas em {PREVISOES_JSON}")
    print(f"   Top 5 prováveis: {alertas['provaveis_top15'][:5]}")
    
    print("\n4. Analisando bolões...")
    boloes_df = load_boloes()
    if not boloes_df.empty:
        ranking = analisar_bolao(boloes_df, previsao, df)
        salvar_ranking_boloes(ranking)
        print(f"   Ranking salvo em {RANKING_BOLOES_CSV}")
        print(f"   {len(ranking)} jogos analisados")
    else:
        print("   Nenhum bolão para analisar")
    
    print("\n" + "=" * 50)
    print("ATUALIZAÇÃO CONCLUÍDA!")
    print("=" * 50)
    
    return {
        'resultados': df,
        'analise': analise,
        'previsao': previsao,
        'alertas': alertas
    }


if __name__ == "__main__":
    update_all()
